package uz.app.jsp.Table.TestModule;

import java.util.LinkedHashMap;

import uz.app.jsp.Table.Options;

public class Department implements Options {
    @Override
    public LinkedHashMap<Object, String> getOptions() {
        LinkedHashMap<Object, String> result = new LinkedHashMap<Object, String>();
        return result;
    }
}
